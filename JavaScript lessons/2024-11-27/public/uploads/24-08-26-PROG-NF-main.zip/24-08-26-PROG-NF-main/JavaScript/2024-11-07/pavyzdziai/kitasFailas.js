console.log("Labas");
