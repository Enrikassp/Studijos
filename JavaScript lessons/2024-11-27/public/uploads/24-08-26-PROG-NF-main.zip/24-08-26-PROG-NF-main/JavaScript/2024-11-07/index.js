// const { getTodaysWeekDayTranslated } = require("./date.js");
import { getTodaysWeekDayTranslated } from "./date.js";

console.log(getTodaysWeekDayTranslated("en", 4));
