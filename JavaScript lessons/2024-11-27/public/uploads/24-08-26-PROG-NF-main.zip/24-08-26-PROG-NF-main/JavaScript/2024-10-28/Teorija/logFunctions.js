export const powerOfSquare = () => 2;
export function multiplyByTen() {
	return 10;
}
