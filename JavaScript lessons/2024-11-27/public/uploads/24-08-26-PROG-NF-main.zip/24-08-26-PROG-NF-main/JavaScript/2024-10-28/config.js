export const language = "EN"; // "LT"|"EN"
// export const theme = "dark"; // "light"|"dark"

// Exportuojama gali būti:
// įprasti kintamieji (null, undefined, boolean, number, string)
// kompleksiški kintamieji: (array, object, Class objektai, class)
// Funkcijos
