// export default 3.1415;
export default () => {
	return 3.1415;
};
