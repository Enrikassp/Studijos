export const powerOfSquare = (number) => {
	return number * number;
};
export function multiplyByTen(number) {
	return number * 10;
}
