const array = ["a", "b", "c", "d"];

const slicedArray = array.slice(1, 4); // ["b", "c", "d"]
console.log(slicedArray);

// array.slice(startIndex)
const firstTwo = array.slice(-1); // ["c", "d"];
console.log(firstTwo);
