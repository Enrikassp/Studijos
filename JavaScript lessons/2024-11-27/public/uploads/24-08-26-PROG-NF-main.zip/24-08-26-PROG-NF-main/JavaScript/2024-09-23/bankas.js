// document.getElementById   - gaunamas elementas pagal ID
// document.querySelector    - gaunamas elementas pagal CSS selektoriu
//  input[type="number"]
// UI - User interface


const vardas = "Justinas",
	algosDydis = 800;
let balansas = 100; //number


initialize();



